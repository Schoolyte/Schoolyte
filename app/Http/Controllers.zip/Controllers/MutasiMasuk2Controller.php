<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class MutasiMasuk2Controller extends Controller
{
    public function index2()
    {
        return view('Beranda.MutasiMasuk2');
    }

}
