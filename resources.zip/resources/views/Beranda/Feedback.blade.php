<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="Style/Feedback.css">
</head>
<body>
    <div class="feedback">
        <img src="assets/Group293.png" class="icon-feedback" />
        <h1>Pendaftaran anda telah berhasil, silahkan tunggu informasi lebih lanjut di email anda!</h1>
        <button type="button" class="btn-back">Kembali</button>
        <div class="kosong"></div>
    </div>
</body>
</html>