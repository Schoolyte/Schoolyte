<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href={{ asset("Style/Footer.css") }}>
</head>
<body>
    <footer>
        <div id="footer" class="footer">

                <div class="box">
                        <div class="boxed">
                            <span>~Enjoy Your School With Schoolyte~</span>
                            <img src="/assets/imgfooter.png" className="imgfooter"  alt="logo" />
                        </div>
                </div>

                <div class="footer-body">
                <div class="footer-col">
                        <div class="footer-logo">
                            <img src="/assets/logo1.png" className="logo-img "  alt="logo" />
                        </div>
                        </div>

                <div>
                <div class="footer-col">
                <img src="/assets/map.png"  class="icon-map"/>
                        <div class="footer-text">

                        <span>Gedung A10 Teknik Informatika, <br/>
                                            Universitas Negeri Surabaya <br/>
                                            Ketintang, Gayungan, Surabaya</span>
                        </div>
                        </div>


                    <img src="/assets/telpon.png" class="icon-contact"/>
                    <img src="/assets/Mail.png" class="icon-email"/>
                    </div>
                    <div class="footer-col">
                    <img src="/assets/Copyright.png" class="icon-copy"/>
                        <div class="footer-text2">
                        <span class="material-symbols-outlined">Copyright Schoolyte 2022</span>
                        </div>
                    </div>
                    <div class="kontak">
                    <div class="footer-col">
                            <span>Kontak Kami</span>   <br> <br>
                            <div class="underkontak"
                            <span> 0321  855461</span>   <br><br>

                            <span>schoolyte@gmail.com</span>
                            </div>
                    </div>
                    </div>
                    </div>
            <div>
        </div>
        </div>
    </footer>
</body>
</html>
